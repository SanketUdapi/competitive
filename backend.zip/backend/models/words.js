const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const words = new Schema({
    word: {
        type: String,
        required: true,
    },
});

module.exports = mongoose.model("words", words);